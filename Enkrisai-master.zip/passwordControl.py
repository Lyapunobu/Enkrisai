from password.passwordGenerator import passwordGenerator

passwordGenerator()