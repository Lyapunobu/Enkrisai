import os
from menu.login_menu import main_menu

if __name__ == "__main__":
    os.system('cls')
    main_menu()

# RAAAAAAAAAAAAAAAAAAAAAAAAH